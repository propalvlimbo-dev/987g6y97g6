Elytrix — Крылья Зевса (Zeus Wings) Redesign Update
=====================================================

1. Скопировать на сервер:
   - plugins/ModelEngine/blueprints/elytrix_zeus_wings.bbmodel
   - plugins/ModelEngine/resource pack/assets/modelengine/models/elytrix_zeus_wings/*.json
   - plugins/ModelEngine/resource pack/assets/modelengine/textures/entity/models/elytrix_zeus_wings.png
   - plugins/ModelEngine/resource pack/assets/modelengine/textures/entity/models/elytrix_zeus_wings.png.mcmeta

2. Применить на сервере:
   /meg reload

3. На клиенте / хостинге РП:
   Обновлённый Elytrix-RP-1.21.zip в корне репозитория уже содержит:
   - 33 перекомпилированные модели костей (ID 341..449 совместимы с ModelEngine/.data/cache.json 1:1)
   - 6-кадровую анимированную текстуру (256x1536 + .mcmeta)
   - Новую чёткую иконку 32x32 zeus_wings_icon.png для /акс
