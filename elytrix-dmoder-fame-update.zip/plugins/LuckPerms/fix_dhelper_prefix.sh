#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${1:-${SRV_DIR:-/root/RW_GRIEF}}"
if [ ! -d "$SRV_DIR/plugins" ] && [ -d "$(pwd)/plugins" ]; then
  SRV_DIR="$(pwd)"
fi
LP_DIR="$SRV_DIR/plugins/LuckPerms"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$LP_DIR"
if [ -f "$SCRIPT_DIR/fix_dhelper_prefix.sql" ] && [ "$SCRIPT_DIR/fix_dhelper_prefix.sql" != "$LP_DIR/fix_dhelper_prefix.sql" ]; then
  cp -f "$SCRIPT_DIR/fix_dhelper_prefix.sql" "$LP_DIR/fix_dhelper_prefix.sql"
fi

CMDS=(
  "lp group dhelper parent remove angel"
  "lp group dhelper meta clear prefixes"
  "lp group dhelper setweight 25"
  "lp group dhelper meta setprefix 25 \"&fꕠ &7\""
  "lp group angel parent remove dhelper"
  "lp group angel meta clear prefixes"
  "lp group angel setweight 27"
  "lp group angel meta setprefix 27 \"&fꕓ &7\""
  "lp group dadmin meta clear prefixes"
  "lp group dadmin meta setprefix 29 \"&fꕡ &7\""
  "lp sync"
  "tab reload"
  "cakechat reload"
)

sent=0

# 1) Try tmux
if command -v tmux >/dev/null 2>&1 && tmux ls >/dev/null 2>&1; then
  for sess in $(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{pane_current_command}' 2>/dev/null | awk '/java/{print $1}'); do
    for c in "${CMDS[@]}"; do
      tmux send-keys -t "$sess" -l "$c"
      tmux send-keys -t "$sess" Enter
      sleep 0.1
    done
    sent=1
    echo "[Elytrix LP] Fixed dhelper/angel prefix safely via tmux pane $sess"
    break
  done
fi

# 2) Try screen
if [ "$sent" -eq 0 ] && command -v screen >/dev/null 2>&1; then
  scr=$(screen -ls 2>/dev/null | awk '/\.(.*)\t/ && /Detached|Attached/{print $1}' | head -n1 || true)
  if [ -n "$scr" ]; then
    for c in "${CMDS[@]}"; do
      screen -S "$scr" -p 0 -X stuff "$c$(printf '\r')"
      sleep 0.1
    done
    sent=1
    echo "[Elytrix LP] Fixed dhelper/angel prefix safely via screen session $scr"
  fi
fi

# 3) Try RCON if enabled in server.properties
if [ "$sent" -eq 0 ] && [ -f "$SRV_DIR/server.properties" ] && command -v python3 >/dev/null 2>&1; then
  if python3 - "$SRV_DIR/server.properties" "${CMDS[@]}" << 'PYEOF'
import sys, socket, struct

props = {}
with open(sys.argv[1], encoding="utf-8", errors="ignore") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            props[k.strip()] = v.strip()

if props.get("enable-rcon", "false").lower() != "true":
    sys.exit(1)
pw = props.get("rcon.password", "")
if not pw:
    sys.exit(1)
port = int(props.get("rcon.port", "25575"))

def send_pkt(sock, req_id, ptype, body):
    data = struct.pack("<ii", req_id, ptype) + body.encode("utf-8") + b"\x00\x00"
    sock.sendall(struct.pack("<i", len(data)) + data)

def recv_pkt(sock):
    hdr = b""
    while len(hdr) < 4:
        chunk = sock.recv(4 - len(hdr))
        if not chunk:
            raise EOFError("RCON closed")
        hdr += chunk
    ln = struct.unpack("<i", hdr)[0]
    payload = b""
    while len(payload) < ln:
        chunk = sock.recv(ln - len(payload))
        if not chunk:
            raise EOFError("RCON closed")
        payload += chunk
    rid, rtype = struct.unpack("<ii", payload[:8])
    return rid, rtype, payload[8:-2].decode("utf-8", errors="replace")

s = socket.create_connection(("127.0.0.1", port), timeout=5)
send_pkt(s, 1, 3, pw)
rid, _, _ = recv_pkt(s)
if rid == -1:
    sys.exit(2)
for idx, cmd in enumerate(sys.argv[2:], start=10):
    send_pkt(s, idx, 2, cmd)
    _, _, out = recv_pkt(s)
    if out:
        print(f"  [RCON] {cmd} -> {out.strip()}")
s.close()
PYEOF
  then
    sent=1
    echo "[Elytrix LP] Fixed dhelper/angel prefix safely via RCON"
  fi
fi

# 4) If server is stopped, apply targeted SQL patch directly to H2 DB (preserving all players & other groups)
if [ "$sent" -eq 0 ]; then
  if ! (pgrep -a java 2>/dev/null | grep -qiE "$SRV_DIR|paper|leaf|purpur|spigot|nogui") >/dev/null 2>&1; then
    H2_JAR=$(find "$LP_DIR/libs" -maxdepth 3 -name '*h2*.jar' ! -name '*-sources.jar' 2>/dev/null | head -n1 || true)
    if [ -n "$H2_JAR" ] && [ -f "$LP_DIR/luckperms-h2-v2.mv.db" ] && command -v java >/dev/null 2>&1; then
      cp -f "$LP_DIR/luckperms-h2-v2.mv.db" "$LP_DIR/luckperms-h2-v2.mv.db.bak.$(date +%s)"
      java -cp "$H2_JAR" org.h2.tools.RunScript -url "jdbc:h2:$LP_DIR/luckperms-h2-v2" -user "" -password "" -script "$LP_DIR/fix_dhelper_prefix.sql"
      sent=1
      echo "[Elytrix LP] Applied targeted dhelper/angel SQL fix to stopped H2 DB (players & other groups preserved, backup created)"
    fi
  fi
fi

if [ "$sent" -eq 0 ]; then
  echo "[Elytrix LP] Не удалось подключиться к tmux/screen/RCON, а сервер работает (или H2-драйвер не найден)."
  echo "[Elytrix LP] Выполните вручную в консоли сервера (БЕЗ lp import --replace!):"
  for c in "${CMDS[@]}"; do
    echo "  $c"
  done
  exit 1
fi
