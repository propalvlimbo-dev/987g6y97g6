-- Non-destructive targeted fix for dhelper/angel circular inheritance and prefix priorities.
-- Preserves all users/players and all other LuckPerms groups untouched.
MERGE INTO LUCKPERMS_GROUPS (NAME) KEY (NAME) VALUES ('dhelper'), ('angel'), ('dadmin');
DELETE FROM LUCKPERMS_GROUP_PERMISSIONS
WHERE (NAME = 'dhelper' AND (PERMISSION = 'group.angel' OR PERMISSION LIKE 'prefix.%' OR PERMISSION LIKE 'weight.%'))
   OR (NAME = 'angel' AND (PERMISSION = 'group.dhelper' OR PERMISSION LIKE 'prefix.%' OR PERMISSION LIKE 'weight.%'))
   OR (NAME = 'dadmin' AND PERMISSION LIKE 'prefix.%');
INSERT INTO LUCKPERMS_GROUP_PERMISSIONS (NAME, PERMISSION, VALUE, SERVER, WORLD, EXPIRY, CONTEXTS) VALUES ('dhelper', 'weight.25', TRUE, 'global', 'global', 0, '{}');
INSERT INTO LUCKPERMS_GROUP_PERMISSIONS (NAME, PERMISSION, VALUE, SERVER, WORLD, EXPIRY, CONTEXTS) VALUES ('dhelper', 'prefix.25.&fꕠ &7', TRUE, 'global', 'global', 0, '{}');
INSERT INTO LUCKPERMS_GROUP_PERMISSIONS (NAME, PERMISSION, VALUE, SERVER, WORLD, EXPIRY, CONTEXTS) VALUES ('angel', 'weight.27', TRUE, 'global', 'global', 0, '{}');
INSERT INTO LUCKPERMS_GROUP_PERMISSIONS (NAME, PERMISSION, VALUE, SERVER, WORLD, EXPIRY, CONTEXTS) VALUES ('angel', 'prefix.27.&fꕓ &7', TRUE, 'global', 'global', 0, '{}');
INSERT INTO LUCKPERMS_GROUP_PERMISSIONS (NAME, PERMISSION, VALUE, SERVER, WORLD, EXPIRY, CONTEXTS) VALUES ('dadmin', 'prefix.29.&fꕡ &7', TRUE, 'global', 'global', 0, '{}');
