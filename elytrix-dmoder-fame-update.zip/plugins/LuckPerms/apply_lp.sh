#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${1:-${SRV_DIR:-/root/RW_GRIEF}}"
if [ ! -d "$SRV_DIR/plugins" ] && [ -d "$(pwd)/plugins" ]; then
  SRV_DIR="$(pwd)"
fi
LP_DIR="$SRV_DIR/plugins/LuckPerms"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy non-destructive scripts/SQL/commands into plugins/LuckPerms/
mkdir -p "$LP_DIR"
for f in lp-dmoder-fame.sql lp-dmoder-fame-commands.txt fix_dhelper_prefix.sql fix_dhelper_prefix.sh; do
  if [ -f "$SCRIPT_DIR/$f" ] && [ "$SCRIPT_DIR/$f" != "$LP_DIR/$f" ]; then
    cp -f "$SCRIPT_DIR/$f" "$LP_DIR/$f"
  fi
done

if [ ! -f "$LP_DIR/lp-dmoder-fame-commands.txt" ] || [ ! -f "$LP_DIR/lp-dmoder-fame.sql" ]; then
  echo "[Elytrix LP] ERROR: lp-dmoder-fame-commands.txt or lp-dmoder-fame.sql not found in $LP_DIR!"
  exit 1
fi

# Read all non-comment, non-empty commands from lp-dmoder-fame-commands.txt + plugin reloads.
# NEVER uses `lp import --replace` (which would wipe players and unrelated groups!).
CMDS=()
while IFS= read -r line || [ -n "$line" ]; do
  line="${line#"${line%%[![:space:]]*}"}"
  line="${line%"${line##*[![:space:]]}"}"
  if [ -z "$line" ] || [[ "$line" == \#* ]]; then
    continue
  fi
  CMDS+=("$line")
done < "$LP_DIR/lp-dmoder-fame-commands.txt"

CMDS+=(
  "dm reload"
  "dh reload"
  "bcases reload"
  "eg reload"
  "elytrixrp reload"
  "essentials reload"
  "litebans reload"
  "granter reload"
  "wg reload"
  "ca reload"
  "rwitems reload"
)

sent=0

# 1) Try tmux
if command -v tmux >/dev/null 2>&1 && tmux ls >/dev/null 2>&1; then
  for sess in $(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{pane_current_command}' 2>/dev/null | awk '/java/{print $1}'); do
    for c in "${CMDS[@]}"; do
      tmux send-keys -t "$sess" -l "$c"
      tmux send-keys -t "$sess" Enter
      sleep 0.05
    done
    sent=1
    echo "[Elytrix LP] Applied non-destructively via tmux pane $sess (${#CMDS[@]} commands)"
    break
  done
fi

# 2) Try screen
if [ "$sent" -eq 0 ] && command -v screen >/dev/null 2>&1; then
  scr=$(screen -ls 2>/dev/null | awk '/\.(.*)\t/ && /Detached|Attached/{print $1}' | head -n1 || true)
  if [ -n "$scr" ]; then
    for c in "${CMDS[@]}"; do
      screen -S "$scr" -p 0 -X stuff "$c$(printf '\r')"
      sleep 0.05
    done
    sent=1
    echo "[Elytrix LP] Applied non-destructively via screen session $scr (${#CMDS[@]} commands)"
  fi
fi

# 3) Try RCON if enabled in server.properties
if [ "$sent" -eq 0 ] && [ -f "$SRV_DIR/server.properties" ] && command -v python3 >/dev/null 2>&1; then
  if python3 - "$SRV_DIR/server.properties" "${CMDS[@]}" << 'PYEOF'
import sys, socket, struct

props = {}
with open(sys.argv[1], encoding="utf-8", errors="ignore") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            props[k.strip()] = v.strip()

if props.get("enable-rcon", "false").lower() != "true":
    sys.exit(1)
pw = props.get("rcon.password", "")
if not pw:
    sys.exit(1)
port = int(props.get("rcon.port", "25575"))

def send_pkt(sock, req_id, ptype, body):
    data = struct.pack("<ii", req_id, ptype) + body.encode("utf-8") + b"\x00\x00"
    sock.sendall(struct.pack("<i", len(data)) + data)

def recv_pkt(sock):
    hdr = b""
    while len(hdr) < 4:
        chunk = sock.recv(4 - len(hdr))
        if not chunk:
            raise EOFError("RCON closed")
        hdr += chunk
    ln = struct.unpack("<i", hdr)[0]
    payload = b""
    while len(payload) < ln:
        chunk = sock.recv(ln - len(payload))
        if not chunk:
            raise EOFError("RCON closed")
        payload += chunk
    rid, rtype = struct.unpack("<ii", payload[:8])
    return rid, rtype, payload[8:-2].decode("utf-8", errors="replace")

s = socket.create_connection(("127.0.0.1", port), timeout=5)
send_pkt(s, 1, 3, pw)
rid, _, _ = recv_pkt(s)
if rid == -1:
    sys.exit(2)
for idx, cmd in enumerate(sys.argv[2:], start=10):
    send_pkt(s, idx, 2, cmd)
    _, _, out = recv_pkt(s)
    if out:
        print(f"  [RCON] {cmd} -> {out.strip()}")
s.close()
PYEOF
  then
    sent=1
    echo "[Elytrix LP] Applied non-destructively via RCON (${#CMDS[@]} commands)"
  fi
fi

# 4) If server is stopped, apply targeted SQL patch directly to H2 DB (preserves players & other groups)
if [ "$sent" -eq 0 ]; then
  if ! (pgrep -a java 2>/dev/null | grep -qiE "$SRV_DIR|paper|leaf|purpur|spigot|nogui") >/dev/null 2>&1; then
    H2_JAR=$(find "$LP_DIR/libs" -maxdepth 3 -name '*h2*.jar' ! -name '*-sources.jar' 2>/dev/null | head -n1 || true)
    if [ -n "$H2_JAR" ] && [ -f "$LP_DIR/luckperms-h2-v2.mv.db" ] && command -v java >/dev/null 2>&1; then
      cp -f "$LP_DIR/luckperms-h2-v2.mv.db" "$LP_DIR/luckperms-h2-v2.mv.db.bak.$(date +%s)"
      java -cp "$H2_JAR" org.h2.tools.RunScript -url "jdbc:h2:$LP_DIR/luckperms-h2-v2" -user "" -password "" -script "$LP_DIR/lp-dmoder-fame.sql"
      sent=1
      echo "[Elytrix LP] Applied SQL patch directly to stopped H2 DB (players & unrelated groups preserved, backup created)"
    fi
  fi
fi

if [ "$sent" -eq 0 ]; then
  echo "[Elytrix LP] Server is running outside tmux/screen and RCON is disabled."
  echo "[Elytrix LP] Do NOT use 'lp import --replace' (it wipes players and other groups)."
  echo "[Elytrix LP] Either stop the server and re-run 'bash $LP_DIR/apply_lp.sh $SRV_DIR' (runs safe SQL patch),"
  echo "[Elytrix LP] OR paste the commands from: $LP_DIR/lp-dmoder-fame-commands.txt"
  exit 1
fi
