#!/usr/bin/env bash
set -euo pipefail
SRV_DIR="/root/RW_GRIEF"
LP_DIR="$SRV_DIR/plugins/LuckPerms"
CMDS=(
  "lp import lp-dmoder-fame.json --replace"
  "lp sync"
  "dm reload"
  "dh reload"
  "elytrixrp reload"
  "essentials reload"
  "cakechat reload"
  "litebans reload"
  "granter reload"
  "wgex reload"
  "ca reload"
)

sent=0
# 1) Try tmux if server process runs inside tmux
if command -v tmux >/dev/null 2>&1 && tmux ls >/dev/null 2>&1; then
  for sess in $(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{pane_current_command}' 2>/dev/null | awk '/java/{print $1}'); do
    for c in "${CMDS[@]}"; do
      tmux send-keys -t "$sess" "$c" Enter
    done
    sent=1
    echo "[LuckPerms] Applied via tmux pane $sess"
    break
  done
fi

# 2) Try screen if not sent via tmux
if [ "$sent" -eq 0 ] && command -v screen >/dev/null 2>&1; then
  scr=$(screen -ls 2>/dev/null | awk '/\.(.*)\t/ && /Detached|Attached/{print $1}' | head -n1 || true)
  if [ -n "$scr" ]; then
    for c in "${CMDS[@]}"; do
      screen -S "$scr" -p 0 -X stuff "$c$(printf '\r')"
    done
    sent=1
    echo "[LuckPerms] Applied via screen session $scr"
  fi
fi

# 3) If server is stopped (no RW_GRIEF java process), apply SQL directly to H2 preserving all players
if [ "$sent" -eq 0 ]; then
  if ! pgrep -f "$SRV_DIR|paper|leaf" >/dev/null 2>&1; then
    H2_JAR=$(find "$LP_DIR/libs" -maxdepth 2 -name 'h2-*.jar' 2>/dev/null | head -n1 || true)
    if [ -n "$H2_JAR" ] && [ -f "$LP_DIR/luckperms-h2-v2.mv.db" ] && command -v java >/dev/null 2>&1; then
      cp -f "$LP_DIR/luckperms-h2-v2.mv.db" "$LP_DIR/luckperms-h2-v2.mv.db.bak.$(date +%s)"
      java -cp "$H2_JAR" org.h2.tools.RunScript -url "jdbc:h2:$LP_DIR/luckperms-h2-v2" -user "" -password "" -script "$LP_DIR/lp-dmoder-fame.sql"
      sent=1
      echo "[LuckPerms] Applied SQL patch directly to stopped H2 DB (players preserved, backup created)"
    fi
  fi
fi

if [ "$sent" -eq 0 ]; then
  echo "[LuckPerms] Server console not attached to screen/tmux; run inside server console:"
  echo "  lp import lp-dmoder-fame.json --replace && lp sync"
  echo "  dm reload && dh reload && elytrixrp reload && essentials reload && cakechat reload && litebans reload"
fi
