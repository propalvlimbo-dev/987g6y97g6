#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif
#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat4 TextureMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
out float elytrixHideRadius;
out float elytrixEyeDist;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    ivec3 elytrixTint = ivec3(Color.rgb * 255.0 + 0.5);
    vec4 baseColor = Color;
    elytrixHideRadius = 0.0;
    if (abs(ProjMat[2][3]) > 1e-4) {
        if (elytrixTint == ivec3(252, 254, 253)) {
            elytrixHideRadius = 1.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (elytrixTint == ivec3(252, 253, 254)) {
            elytrixHideRadius = 2.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    elytrixEyeDist = length((ModelViewMat * vec4(Position, 1.0)).xyz);

    vertexDistance = fog_distance(Position, FogShape);
#ifdef NO_CARDINAL_LIGHTING
    vertexColor = baseColor;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, baseColor);
#endif
    lightMapColor = vec4(1.0);
#ifndef EMISSIVE
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
#endif
    overlayColor = vec4(0.0, 0.0, 0.0, 1.0);
#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
