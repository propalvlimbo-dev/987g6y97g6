#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out float elytrixHideRadius;
out float elytrixEyeDist;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    ivec3 elytrixTint = ivec3(Color.rgb * 255.0 + 0.5);
    vec4 baseColor = Color;
    elytrixHideRadius = 0.0;
    if (abs(ProjMat[2][3]) > 1e-4) {
        if (elytrixTint == ivec3(252, 254, 253)) {
            elytrixHideRadius = 1.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (elytrixTint == ivec3(252, 253, 254)) {
            elytrixHideRadius = 2.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    elytrixEyeDist = length((ModelViewMat * vec4(Position, 1.0)).xyz);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, baseColor) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
}
