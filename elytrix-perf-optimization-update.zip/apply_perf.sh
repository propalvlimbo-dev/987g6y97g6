#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${SRV_DIR:-/root/RW_GRIEF}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
BAK_DIR="$SRV_DIR/.backup_perf_$TS"

UPDATE_FILES=(
  "plugins/DecentHolograms/config.yml"
  "plugins/ElytrixClock/config.yml"
  "plugins/ElytrixSite/config.yml"
  "plugins/ElytrixTops/config.yml"
  "plugins/Essentials/config.yml"
  "plugins/KnockbackSync/config.yml"
  "plugins/LPX/config.yml"
  "plugins/LagFixer/modules/EntityLimiter.yml"
  "plugins/LagFixer/modules/HopperOptimizer.yml"
  "plugins/LagFixer/modules/LagShield.yml"
  "plugins/LagFixer/modules/MobAiReducer.yml"
  "plugins/LagFixer/modules/WorldCleaner.yml"
  "plugins/LiteBans/config.yml"
  "plugins/LuckPerms/apply_lp.sh"
  "plugins/LuckPerms/lp-dmoder-fame-commands.txt"
  "plugins/LuckPerms/lp-dmoder-fame.json"
  "plugins/LuckPerms/lp-dmoder-fame.sql"
  "plugins/Orebfuscator/config.yml"
  "plugins/PlaceholderAPI/config.yml"
  "plugins/PlugManX/config.yml"
  "plugins/RoseGarden/config.yml"
  "plugins/TAB/config.yml"
  "plugins/ViaVersion/config.yml"
  "plugins/WorldGuard/config.yml"
)

echo "[Elytrix Perf] Target server: $SRV_DIR (package: $PKG_DIR)"

if [ "$PKG_DIR" != "$SRV_DIR" ]; then
  echo "[Elytrix Perf] Backing up existing configs -> $BAK_DIR"
  mkdir -p "$BAK_DIR"
  for rel in "${UPDATE_FILES[@]}"; do
    src="$PKG_DIR/$rel"
    dst="$SRV_DIR/$rel"
    if [ ! -f "$src" ]; then
      continue
    fi
    if [ -f "$dst" ]; then
      mkdir -p "$BAK_DIR/$(dirname "$rel")"
      cp -a "$dst" "$BAK_DIR/$rel"
    fi
    mkdir -p "$(dirname "$dst")"
    cp -f "$src" "$dst"
    echo "  [+] Updated $rel"
  done
else
  echo "[Elytrix Perf] Package already extracted inside $SRV_DIR — skipping file copy."
fi

# Clear bloated TAB error logs (16.7MB each)
for logf in "$SRV_DIR/plugins/TAB/errors.log" "$SRV_DIR/plugins/TAB/placeholder-errors.log"; do
  if [ -f "$logf" ]; then
    : > "$logf"
    echo "  [+] Truncated log: ${logf#$SRV_DIR/}"
  fi
done

# Check FloriumAC placeholder SaaS URL
if [ -f "$SRV_DIR/plugins/FloriumAC/saas.yml" ] && grep -qE "http://url|ws://url" "$SRV_DIR/plugins/FloriumAC/saas.yml"; then
  echo "  [!] WARNING: plugins/FloriumAC/saas.yml contains placeholder http://url / ws://url!"
  echo "      Set saas.enabled: false and auto-update.enabled: false or configure a real endpoint."
fi

# Switch SQLite DBs from journal_mode=delete to persistent WAL mode (only safely when server is stopped)
SQLITE_DBS=(
  "plugins/NBattlepass/players.db"
  "plugins/NBattlepass/quests.db"
  "plugins/ElytrixTops/database.db"
  "plugins/PlayerPoints/playerpoints.db"
  "plugins/NEnderChest/items.db"
  "plugins/NEnderChest/playerTimes.db"
  "plugins/hMarket/market.db"
  "plugins/hPvPChest/data.db"
  "plugins/hWarps/database.db"
  "plugins/ElytrixELO/db.db"
  "plugins/ElytrixKiller/data.db"
  "plugins/TradeSystem/tradelog.db"
  "plugins/CakeSubAddon/memory.db"
)

if ! (pgrep -a java 2>/dev/null | grep -qiE "$SRV_DIR|paper|leaf|purpur|spigot|nogui"); then
  if command -v python3 >/dev/null 2>&1; then
    echo "[Elytrix Perf] Server stopped -> switching SQLite databases to persistent WAL mode..."
    mkdir -p "$BAK_DIR"
    for rel in "${SQLITE_DBS[@]}"; do
      db="$SRV_DIR/$rel"
      if [ -f "$db" ]; then
        mkdir -p "$BAK_DIR/$(dirname "$rel")"
        cp -a "$db" "$BAK_DIR/$rel.bak" 2>/dev/null || true
        python3 - "$db" << "PYEOF"
import sqlite3, sys
p = sys.argv[1]
con = sqlite3.connect(p, timeout=10)
cur = con.execute("PRAGMA journal_mode=WAL;").fetchone()
con.execute("PRAGMA synchronous=NORMAL;")
con.close()
print(f"  [WAL] {p} -> {cur[0]}")
PYEOF
      fi
    done
  fi
else
  echo "[Elytrix Perf] Server is running — skipping live SQLite WAL conversion."
  echo "  Stop the server once and re-run ./apply_perf.sh to convert SQLite DBs to WAL mode."
fi

if [ -f "$SRV_DIR/plugins/LuckPerms/apply_lp.sh" ]; then
  chmod +x "$SRV_DIR/plugins/LuckPerms/apply_lp.sh"
  SRV_DIR="$SRV_DIR" bash "$SRV_DIR/plugins/LuckPerms/apply_lp.sh" || true
fi

echo "[Elytrix Perf] Done! Restart the server for all changes (Orebfuscator, PlugManX, SQLite WAL, JVM flags) to take effect."
