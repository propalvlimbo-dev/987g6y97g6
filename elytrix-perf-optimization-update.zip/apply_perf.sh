#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${SRV_DIR:-/root/RW_GRIEF}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
BAK_DIR="$SRV_DIR/.backup_perf_$TS"

UPDATE_FILES=(
  "plugins/DecentHolograms/config.yml"
  "plugins/ElytrixClock/config.yml"
  "plugins/ElytrixEventGuard/config.yml"
  "plugins/ElytrixFreakModel/config.yml"
  "plugins/ElytrixSite/config.yml"
  "plugins/ElytrixTops/config.yml"
  "plugins/Essentials/config.yml"
  "plugins/FastAsyncWorldEdit/config.yml"
  "plugins/GrimAC/config.yml"
  "plugins/HideStream/config.yml"
  "plugins/KnockbackSync/config.yml"
  "plugins/LPX/config.yml"
  "plugins/LagFixer/modules/EntityLimiter.yml"
  "plugins/LagFixer/modules/HopperOptimizer.yml"
  "plugins/LagFixer/modules/LagShield.yml"
  "plugins/LagFixer/modules/MobAiReducer.yml"
  "plugins/LagFixer/modules/WorldCleaner.yml"
  "plugins/LiteBans/config.yml"
  "plugins/LuckPerms/apply_lp.sh"
  "plugins/LuckPerms/lp-dmoder-fame-commands.txt"
  "plugins/LuckPerms/lp-dmoder-fame.json"
  "plugins/LuckPerms/lp-dmoder-fame.sql"
  "plugins/ModelEngine/config.yml"
  "plugins/MythicMobs/config/config-general.yml"
  "plugins/Orebfuscator/config.yml"
  "plugins/PlaceholderAPI/config.yml"
  "plugins/PlugManX/config.yml"
  "plugins/ProtocolLib/config.yml"
  "plugins/RoseGarden/config.yml"
  "plugins/TAB/config.yml"
  "plugins/Vault/config.yml"
  "plugins/ViaVersion/config.yml"
  "plugins/WorldGuard/config.yml"
)

echo "[Elytrix Perf] Target server: $SRV_DIR (package: $PKG_DIR)"

if [ "$PKG_DIR" != "$SRV_DIR" ]; then
  echo "[Elytrix Perf] Backing up existing configs -> $BAK_DIR"
  mkdir -p "$BAK_DIR"
  for rel in "${UPDATE_FILES[@]}"; do
    src="$PKG_DIR/$rel"
    dst="$SRV_DIR/$rel"
    if [ ! -f "$src" ]; then
      continue
    fi
    if [ -f "$dst" ]; then
      mkdir -p "$BAK_DIR/$(dirname "$rel")"
      cp -a "$dst" "$BAK_DIR/$rel"
    fi
    mkdir -p "$(dirname "$dst")"
    cp -f "$src" "$dst"
    echo "  [+] Updated $rel"
  done
else
  echo "[Elytrix Perf] Package already extracted inside $SRV_DIR — skipping file copy."
fi

# Clear bloated TAB error logs (16.7MB each)
for logf in "$SRV_DIR/plugins/TAB/errors.log" "$SRV_DIR/plugins/TAB/placeholder-errors.log"; do
  if [ -f "$logf" ]; then
    : > "$logf"
    echo "  [+] Truncated log: ${logf#$SRV_DIR/}"
  fi
done

# Check FloriumAC placeholder SaaS URL
if [ -f "$SRV_DIR/plugins/FloriumAC/saas.yml" ] && grep -qE "http://url|ws://url" "$SRV_DIR/plugins/FloriumAC/saas.yml"; then
  echo "  [!] WARNING: plugins/FloriumAC/saas.yml contains placeholder http://url / ws://url!"
  echo "      Set saas.enabled: false and auto-update.enabled: false or configure a real endpoint."
fi

# Switch SQLite DBs from journal_mode=delete to persistent WAL mode (only safely when server is stopped)
SQLITE_DBS=(
  "plugins/NBattlepass/players.db"
  "plugins/NBattlepass/quests.db"
  "plugins/ElytrixTops/database.db"
  "plugins/PlayerPoints/playerpoints.db"
  "plugins/NEnderChest/items.db"
  "plugins/NEnderChest/playerTimes.db"
  "plugins/hMarket/market.db"
  "plugins/hPvPChest/data.db"
  "plugins/hWarps/database.db"
  "plugins/ElytrixELO/db.db"
  "plugins/ElytrixKiller/data.db"
  "plugins/TradeSystem/tradelog.db"
  "plugins/CakeSubAddon/memory.db"
)

if ! (pgrep -a java 2>/dev/null | grep -qiE "$SRV_DIR|paper|leaf|purpur|spigot|nogui"); then
  if command -v python3 >/dev/null 2>&1; then
    echo "[Elytrix Perf] Server stopped -> switching SQLite databases to persistent WAL mode..."
    mkdir -p "$BAK_DIR"
    for rel in "${SQLITE_DBS[@]}"; do
      db="$SRV_DIR/$rel"
      if [ -f "$db" ]; then
        mkdir -p "$BAK_DIR/$(dirname "$rel")"
        cp -a "$db" "$BAK_DIR/$rel.bak" 2>/dev/null || true
        python3 - "$db" << "PYEOF"
import sqlite3, sys
p = sys.argv[1]
con = sqlite3.connect(p, timeout=10)
cur = con.execute("PRAGMA journal_mode=WAL;").fetchone()
con.execute("PRAGMA synchronous=NORMAL;")
con.close()
print(f"  [WAL] {p} -> {cur[0]}")
PYEOF
      fi
    done
  fi
else
  echo "[Elytrix Perf] Server is running — skipping live SQLite WAL conversion."
  echo "  Stop the server once and re-run ./apply_perf.sh to convert SQLite DBs to WAL mode."
fi


# Tune ShieldSpigot/Paper/Leaf/Spigot core configs for 3 CPU threads (if present)
if command -v python3 >/dev/null 2>&1; then
  echo "[Elytrix Perf] Checking core server configs (spigot/paper/leaf) for 3-thread optimization..."
  python3 - "$SRV_DIR" "$BAK_DIR" << 'PYEOF'
import os, re, shutil, sys

srv, bak = sys.argv[1], sys.argv[2]

def backup_and_patch(rel, fn):
    p = os.path.join(srv, rel)
    if not os.path.isfile(p):
        return False
    with open(p, encoding="utf-8", errors="replace") as f:
        orig = f.read()
    new = fn(orig)
    if new != orig:
        bp = os.path.join(bak, rel)
        os.makedirs(os.path.dirname(bp), exist_ok=True)
        if not os.path.exists(bp):
            shutil.copy2(p, bp)
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(new)
        print(f"  [+] Tuned {rel}")
        return True
    return False

def replace_in_section(text, section_header, key, old_val, new_val):
    lines = text.splitlines(keepends=True)
    in_sec = False
    sec_indent = -1
    out = []
    pat = re.compile(rf"^(\s*){re.escape(key)}:\s*{re.escape(old_val)}(\s*(?:#.*)?)$")
    sec_pat = re.compile(rf"^(\s*){re.escape(section_header)}:\s*(?:#.*)?$")
    for ln in lines:
        stripped = ln.strip()
        if stripped and not stripped.startswith("#"):
            indent = len(ln) - len(ln.lstrip(" "))
            if in_sec and indent <= sec_indent:
                in_sec = False
            m_sec = sec_pat.match(ln.rstrip("\r\n"))
            if m_sec:
                in_sec = True
                sec_indent = len(m_sec.group(1))
                out.append(ln)
                continue
            if in_sec:
                m = pat.match(ln.rstrip("\r\n"))
                if m:
                    eol = "\n" if ln.endswith("\n") else ""
                    out.append(f"{m.group(1)}{key}: {new_val}{m.group(2)}{eol}")
                    continue
        out.append(ln)
    return "".join(out)

backup_and_patch("spigot.yml", lambda t: re.sub(r"^(\s*netty-threads:\s*)4\b", r"\g<1>2", t, flags=re.M))

def patch_paper_global(t):
    t = replace_in_section(t, "chunk-system", "worker-threads", "2", "1")
    t = replace_in_section(t, "chunk-loading-advanced", "player-max-concurrent-chunk-generates", "2", "1")
    t = replace_in_section(t, "chunk-loading-advanced", "player-max-concurrent-chunk-loads", "4", "2")
    t = replace_in_section(t, "chunk-loading-basic", "player-max-chunk-generate-rate", "20.0", "10.0")
    t = replace_in_section(t, "chunk-loading-basic", "player-max-chunk-load-rate", "50.0", "30.0")
    t = replace_in_section(t, "chunk-loading-basic", "player-max-chunk-send-rate", "45.0", "25.0")
    return t

backup_and_patch("config/paper-global.yml", patch_paper_global)
backup_and_patch("config/paper-world-defaults.yml", lambda t: replace_in_section(t, "hopper", "disable-move-event", "false", "true"))

def patch_leaf(t):
    t = replace_in_section(t, "async-pathfinding", "max-threads", "2", "1")
    t = replace_in_section(t, "region-format", "io-thread-count", "2", "1")
    return t

for cand in ("config/leaf-global.yml", "config/leaf/global.yml", "leaf/global.yml", "leaf.yml"):
    backup_and_patch(cand, patch_leaf)
PYEOF
fi

if [ -f "$SRV_DIR/plugins/LuckPerms/apply_lp.sh" ]; then
  chmod +x "$SRV_DIR/plugins/LuckPerms/apply_lp.sh"
  SRV_DIR="$SRV_DIR" bash "$SRV_DIR/plugins/LuckPerms/apply_lp.sh" || true
fi

echo "[Elytrix Perf] Done! Restart the server for all changes (Orebfuscator, PlugManX, SQLite WAL, JVM flags) to take effect."
