#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${1:-$(pwd)}"
if [ ! -d "$SRV_DIR/plugins" ] && [ -d "/root/RW_GRIEF/plugins" ]; then
  SRV_DIR="/root/RW_GRIEF"
fi
if [ ! -d "$SRV_DIR/plugins" ]; then
  echo "Ошибка: не найдена папка plugins в $SRV_DIR. Укажите путь к серверу: bash apply_prohibition.sh /root/RW_GRIEF"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$SRV_DIR/backups/elytrix-prohibition-$TS"
mkdir -p "$BACKUP_DIR"

# 1. Бэкап и удаление старого ElytrixGodPickup.jar
if [ -f "$SRV_DIR/plugins/ElytrixGodPickup.jar" ]; then
  cp -a "$SRV_DIR/plugins/ElytrixGodPickup.jar" "$BACKUP_DIR/ElytrixGodPickup.jar"
  rm -f "$SRV_DIR/plugins/ElytrixGodPickup.jar"
  echo "[OK] Старый ElytrixGodPickup.jar сохранён в бэкап и удалён."
fi

# 2. Установка ElytrixProhibition.jar v2.6.2 и config.yml
if [ -f "$SRV_DIR/plugins/ElytrixProhibition.jar" ]; then
  cp -a "$SRV_DIR/plugins/ElytrixProhibition.jar" "$BACKUP_DIR/ElytrixProhibition.jar.prev"
fi
cp -f "$SCRIPT_DIR/plugins/ElytrixProhibition.jar" "$SRV_DIR/plugins/ElytrixProhibition.jar"
mkdir -p "$SRV_DIR/plugins/ElytrixProhibition"

EP_CFG="$SRV_DIR/plugins/ElytrixProhibition/config.yml"
if [ ! -f "$EP_CFG" ]; then
  cp -f "$SCRIPT_DIR/plugins/ElytrixProhibition/config.yml" "$EP_CFG"
  echo "[OK] Создан plugins/ElytrixProhibition/config.yml"
else
  cp -a "$EP_CFG" "$BACKUP_DIR/ElytrixProhibition-config.yml"
  if ! grep -q '^wind-charge-cooldown:' "$EP_CFG"; then
    cat >> "$EP_CFG" << 'YMLEOF'

wind-charge-cooldown:
  enabled: true
  # Cooldown in seconds between Wind Charge uses (1 throw per 5 seconds by default)
  seconds: 5.0
  # ActionBar warning shown when holding or attempting to throw a Wind Charge on cooldown (%time% = remaining seconds)
  message: "§f §fЗаряд ветра можно использовать через §x§F§8§B§E§F§B%time% сек."
YMLEOF
    echo "[OK] Добавлена секция wind-charge-cooldown в $EP_CFG"
  fi
  if ! grep -q '^pvp-fly-prohibition:' "$EP_CFG"; then
    cat >> "$EP_CFG" << 'YMLEOF'

pvp-fly-prohibition:
  enabled: true
  # World and WorldGuard regions where /fly is automatically disabled and blocked
  world: world_spawn
  regions:
    - pvp
    - cabinka1
    - cabinka2
  # Players with this explicit permission (or in CREATIVE/SPECTATOR mode) keep /fly inside the PvP regions
  bypass-permission: elytrix.prohibition.pvp-fly.bypass
  # If false, OP and wildcard '*' do NOT bypass /fly prohibition (only explicit permission or Creative/Spectator)
  allow-op-or-wildcard-bypass: false
  message: "§x§F§8§B§E§F§BElytrix §8» §fВ PvP-зоне запрещено использовать §x§F§8§B§E§F§B/fly§f!"
  actionbar: "§f §fВ PvP-зоне запрещено использовать §x§F§8§B§E§F§B/fly§f!"
YMLEOF
    echo "[OK] Добавлена секция pvp-fly-prohibition в $EP_CFG"
  elif ! grep -q 'allow-op-or-wildcard-bypass:' "$EP_CFG"; then
    if command -v python3 >/dev/null 2>&1; then
      python3 - "$EP_CFG" << 'PYEOF'
import sys
path = sys.argv[1]
txt = open(path, "r", encoding="utf-8").read()
lines = txt.splitlines(keepends=True)
out = []
in_sec = False
inserted = False
for line in lines:
    if line.startswith("pvp-fly-prohibition:"):
        in_sec = True
    elif in_sec and line.strip() and not line.startswith(" ") and not line.startswith("#"):
        if not inserted:
            out.append("  allow-op-or-wildcard-bypass: false\n")
            inserted = True
        in_sec = False
    out.append(line)
    if in_sec and not inserted and "bypass-permission:" in line:
        eol = "\r\n" if line.endswith("\r\n") else "\n"
        out.append(f"  allow-op-or-wildcard-bypass: false{eol}")
        inserted = True
if in_sec and not inserted:
    out.append("  allow-op-or-wildcard-bypass: false\n")
with open(path, "w", encoding="utf-8", newline="") as f:
    f.write("".join(out))
PYEOF
    else
      sed -i -E '/bypass-permission:/a\  allow-op-or-wildcard-bypass: false' "$EP_CFG"
    fi
    echo "[OK] Добавлен allow-op-or-wildcard-bypass: false в $EP_CFG"
  fi
  echo "[OK] Существующий $EP_CFG обновлён без потери настроек."
fi
echo "[OK] Установлен plugins/ElytrixProhibition.jar (v2.6.2)"

# 3. Обновление WorldGuard regions.yml для world_spawn (pvp/cabinka2 priority 5, pvp max.y=319, blocked-cmds)
WG_REG="$SRV_DIR/plugins/WorldGuard/worlds/world_spawn/regions.yml"
mkdir -p "$(dirname "$WG_REG")"
if [ -f "$WG_REG" ]; then
  cp -a "$WG_REG" "$BACKUP_DIR/world_spawn-regions.yml"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$WG_REG" << 'PYEOF'
import sys, re

path = sys.argv[1]
raw = open(path, "r", encoding="utf-8").read()
lines = raw.splitlines(keepends=True)
out = []
cur = None
changed = False
for line in lines:
    m = re.match(r'^    ([A-Za-z0-9_]+):\s*$', line)
    if m:
        cur = m.group(1)
    if cur in ("pvp", "cabinka1", "cabinka2"):
        if re.match(r'^            blocked-cmds:\s*\[.*\]\s*$', line):
            indent = line[:len(line) - len(line.lstrip())]
            eol = "\r\n" if line.endswith("\r\n") else "\n"
            newline = f"{indent}blocked-cmds: [/fly, /efly, /essentials:fly, /essentials:efly]{eol}"
            if newline != line:
                changed = True
                line = newline
        elif cur in ("pvp", "cabinka2") and re.match(r'^        priority:\s*0\s*$', line):
            eol = "\r\n" if line.endswith("\r\n") else "\n"
            line = f"        priority: 5{eol}"
            changed = True
        elif cur == "pvp" and re.match(r'^        max:\s*\{x:\s*-36,\s*y:\s*150,\s*z:\s*27\}\s*$', line):
            eol = "\r\n" if line.endswith("\r\n") else "\n"
            line = f"        max: {{x: -36, y: 319, z: 27}}{eol}"
            changed = True
    out.append(line)
if changed:
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write("".join(out))
    print(f"[OK] Обновлён {path} (priority: 5 на pvp и cabinka2, pvp max.y=319, blocked-cmds расширен)")
else:
    print(f"[INFO] {path} уже актуален или структура отличается (бэкап сохранён)")
PYEOF
  else
    cp -f "$SCRIPT_DIR/plugins/WorldGuard/worlds/world_spawn/regions.yml" "$WG_REG"
    echo "[OK] Установлен обновлённый $WG_REG (бэкап сохранён)"
  fi
else
  cp -f "$SCRIPT_DIR/plugins/WorldGuard/worlds/world_spawn/regions.yml" "$WG_REG"
  echo "[OK] Установлен $WG_REG"
fi

# 4. Обновление SHA-1 в plugins/ElytrixRP/config.yml
RP_SHA1="567f9d4566afd964d58d0bdcde215f958dd687c2"
RP_CFG="$SRV_DIR/plugins/ElytrixRP/config.yml"
if [ -f "$RP_CFG" ]; then
  cp -a "$RP_CFG" "$BACKUP_DIR/ElytrixRP-config.yml"
  sed -i -E "s|^sha1:.*|sha1: \"$RP_SHA1\"|" "$RP_CFG"
  echo "[OK] Обновлён sha1 ресурспака в $RP_CFG -> $RP_SHA1"
else
  mkdir -p "$SRV_DIR/plugins/ElytrixRP"
  cp -f "$SCRIPT_DIR/plugins/ElytrixRP/config.yml" "$RP_CFG"
  echo "[OK] Установлен $RP_CFG"
fi

# 5. Поиск и размещение обновлённого Elytrix-RP-1.21.zip, если лежит рядом
UPDATED_RP=""
for cand in "$SCRIPT_DIR/Elytrix-RP-1.21.zip" "$SRV_DIR/Elytrix-RP-1.21.zip" "/root/Elytrix-RP-1.21.zip"; do
  if [ -f "$cand" ]; then
    CUR_SHA="$(sha1sum "$cand" | awk '{print $1}')"
    if [ "$CUR_SHA" = "$RP_SHA1" ]; then
      UPDATED_RP="$cand"
      break
    fi
  fi
done

if [ -n "$UPDATED_RP" ]; then
  DST_LIST=("$SRV_DIR/rp/Elytrix-RP-1.21.zip")
  if [ -d "/root/RP" ] || [ "$(id -u)" -eq 0 ]; then
    DST_LIST+=("/root/RP/Elytrix-RP-1.21.zip")
  fi
  for dst in "${DST_LIST[@]}"; do
    mkdir -p "$(dirname "$dst")"
    if [ "$UPDATED_RP" != "$dst" ]; then
      cp -f "$UPDATED_RP" "$dst"
    fi
    echo "[OK] Обновлён ресурспак: $dst"
  done
else
  echo "[WARN] Не забудьте заменить Elytrix-RP-1.21.zip в /root/RP/ (и/или $SRV_DIR/rp/) на новый архив с sha1=$RP_SHA1"
fi

echo ""
echo "Готово! ВАЖНО: для загрузки нового ElytrixProhibition.jar v2.6.2 перезапустите сервер (рекомендуется)"
echo "или выполните в консоли сервера:"
echo "  wg reload"
echo "  plugman reload ElytrixProhibition"
echo "  elytrixrp reload"
echo "Проверить загруженную версию: ver ElytrixProhibition (должно быть 2.6.2)"
