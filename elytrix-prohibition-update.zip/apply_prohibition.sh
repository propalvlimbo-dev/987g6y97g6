#!/usr/bin/env bash
set -euo pipefail

SRV_DIR="${1:-$(pwd)}"
if [ ! -d "$SRV_DIR/plugins" ] && [ -d "/root/RW_GRIEF/plugins" ]; then
  SRV_DIR="/root/RW_GRIEF"
fi
if [ ! -d "$SRV_DIR/plugins" ]; then
  echo "Ошибка: не найдена папка plugins в $SRV_DIR. Укажите путь к серверу: bash apply_prohibition.sh /root/RW_GRIEF"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$SRV_DIR/backups/elytrix-prohibition-$TS"
mkdir -p "$BACKUP_DIR"

# 1. Бэкап и удаление старого ElytrixGodPickup.jar
if [ -f "$SRV_DIR/plugins/ElytrixGodPickup.jar" ]; then
  cp -a "$SRV_DIR/plugins/ElytrixGodPickup.jar" "$BACKUP_DIR/ElytrixGodPickup.jar"
  rm -f "$SRV_DIR/plugins/ElytrixGodPickup.jar"
  echo "[OK] Старый ElytrixGodPickup.jar сохранён в бэкап и удалён."
fi

# 2. Установка ElytrixProhibition.jar и config.yml
if [ -f "$SRV_DIR/plugins/ElytrixProhibition.jar" ]; then
  cp -a "$SRV_DIR/plugins/ElytrixProhibition.jar" "$BACKUP_DIR/ElytrixProhibition.jar.prev"
fi
cp -f "$SCRIPT_DIR/plugins/ElytrixProhibition.jar" "$SRV_DIR/plugins/ElytrixProhibition.jar"
mkdir -p "$SRV_DIR/plugins/ElytrixProhibition"
if [ ! -f "$SRV_DIR/plugins/ElytrixProhibition/config.yml" ]; then
  cp -f "$SCRIPT_DIR/plugins/ElytrixProhibition/config.yml" "$SRV_DIR/plugins/ElytrixProhibition/config.yml"
  echo "[OK] Создан plugins/ElytrixProhibition/config.yml"
else
  echo "[INFO] Существующий plugins/ElytrixProhibition/config.yml сохранён."
fi
echo "[OK] Установлен plugins/ElytrixProhibition.jar"

# 3. Обновление SHA-1 в plugins/ElytrixRP/config.yml
RP_SHA1="c31b5334e1b1443c09583f8cb01055080e2eb30a"
RP_CFG="$SRV_DIR/plugins/ElytrixRP/config.yml"
if [ -f "$RP_CFG" ]; then
  cp -a "$RP_CFG" "$BACKUP_DIR/ElytrixRP-config.yml"
  sed -i -E "s|^sha1:.*|sha1: \"$RP_SHA1\"|" "$RP_CFG"
  echo "[OK] Обновлён sha1 ресурспака в $RP_CFG -> $RP_SHA1"
else
  mkdir -p "$SRV_DIR/plugins/ElytrixRP"
  cp -f "$SCRIPT_DIR/plugins/ElytrixRP/config.yml" "$RP_CFG"
  echo "[OK] Установлен $RP_CFG"
fi

# 4. Поиск и размещение обновлённого Elytrix-RP-1.21.zip, если лежит рядом
UPDATED_RP=""
for cand in "$SCRIPT_DIR/Elytrix-RP-1.21.zip" "$SRV_DIR/Elytrix-RP-1.21.zip" "/root/Elytrix-RP-1.21.zip"; do
  if [ -f "$cand" ]; then
    CUR_SHA="$(sha1sum "$cand" | awk '{print $1}')"
    if [ "$CUR_SHA" = "$RP_SHA1" ]; then
      UPDATED_RP="$cand"
      break
    fi
  fi
done

if [ -n "$UPDATED_RP" ]; then
  DST_LIST=("$SRV_DIR/rp/Elytrix-RP-1.21.zip")
  if [ -d "/root/RP" ] || [ "$(id -u)" -eq 0 ]; then
    DST_LIST+=("/root/RP/Elytrix-RP-1.21.zip")
  fi
  for dst in "${DST_LIST[@]}"; do
    mkdir -p "$(dirname "$dst")"
    if [ "$UPDATED_RP" != "$dst" ]; then
      cp -f "$UPDATED_RP" "$dst"
    fi
    echo "[OK] Обновлён ресурспак: $dst"
  done
else
  echo "[WARN] Не забудьте заменить Elytrix-RP-1.21.zip в /root/RP/ (и/или $SRV_DIR/rp/) на новый архив с sha1=$RP_SHA1"
fi

echo ""
echo "Готово! Перезапустите сервер (или выполните /elytrixrp reload после обновления RP-файла)."
